import { Route } from "react-router-dom";


const routes = [
    {
        path: "login",
        component: Login
     },
     {
        path: "cadastro",
        component: Cadastro
     }
]