import React, { useState } from "react";
import Request from "../../../request"
import { useNavigate} from "react-router-dom"
import { Button, Form } from "react-bootstrap";

function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [validated, setValidated] = useState(false)

    const navigate = useNavigate()

    // Request do login
    const handleLogin = (() => {
        if(email && password){
            Request.login(email, password)
            .then((res) => {
                if(res) {
                    navigate("../map")
                    window.location.reload()
                }
            })
        }
        setValidated(true);
    });
    // Pagina do login
    return(
        <div class="col-lg-4 col-md-8 col-12 mx-auto mt-5">
            <div class="card z-index-0 fadeIn3 fadeInBottom">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-table shadow-dark border-radius-lg pt-4 pb-3">
                        <h2 class="text-white font-weight-bolder text-center mt-2 mb-0 p-2">Login</h2>
                    </div>
                </div>
                <div class="card-body">
                    <Form validated={validated} className="text-start">
                        <div className="form-floating input-group input-group-outline">
                            <Form.Control
                                required
                                type="email"
                                className="form-control shadow-dark mb-2 input-group input-group-outline my-3" 
                                id="floatingInput" 
                                value={email} 
                                onChange={e => setEmail(e.target.value)}
                                placeholder="name@example.com"
                            />
                            <label htmlFor="floatingInput" className="form-label">Email</label>
                            <Form.Control.Feedback/>
                            <Form.Control.Feedback type="invalid">
                                Campo não pode ficar em branco.
                            </Form.Control.Feedback>
                        </div>
                        <div className="form-floating input-group input-group-outline">
                            <Form.Control
                                required
                                type="password" 
                                className="form-control shadow-dark mb-2 input-group input-group-outline my-3" 
                                id="floatingPassword" 
                                value={password} 
                                onChange={e => setPassword(e.target.value)}
                                placeholder="password"
                            />
                            <label htmlFor="floatingPassword" className="form-label">Senha</label>
                            <Form.Control.Feedback/>
                            <Form.Control.Feedback type="invalid">
                                Campo não pode ficar em branco.
                            </Form.Control.Feedback>
                        </div>
                        <div className="d-flex justify-content-center mt-4">
                            <Button type="button" onClick={handleLogin} className="btn-md bg-dark text-white btn btn-primary">ENTRAR</Button>
                        </div>
                    </Form>
                </div>
            </div>
        </div>
        // <div className="card-body container d-flex justify-content-center text-center align-items-center">
        //     <div className="card mt-5 w-50 mb-5 bg-body rounded">
        //         <div className="card-body bg-dark rounded">
        //             <Form validated={validated}>
                        // <h1 className="h1 mb-3 text-white fw-normal">Login</h1>
                        // <hr className="text-white hr"></hr>
                        // <div className="form-floating col-md-6 w-100">
                        //     <Form.Control
                        //         required
                        //         type="email"
                        //         className="form-control" 
                        //         id="floatingInput" 
                        //         value={email} 
                        //         onChange={e => setEmail(e.target.value)}
                        //         placeholder="name@example.com"
                        //     />
                        //     {/* <input 
                        //         type="email"
                        //         className="form-control" 
                        //         id="floatingInput" 
                        //         value={email} 
                        //         onChange={e => setEmail(e.target.value)}
                        //         placeholder="name@example.com"/> */}
                        //     <label htmlFor="floatingInput">Email</label>
                        //     <Form.Control.Feedback/>
                        //     <Form.Control.Feedback type="invalid">
                        //         Campo não pode ficar em branco.
                        //     </Form.Control.Feedback>
                        // </div>
                        // <div className="form-floating col-md-6 w-100">
                        //     <Form.Control
                        //         required
                        //         type="password" 
                        //         className="form-control" 
                        //         id="floatingPassword" 
                        //         value={password} 
                        //         onChange={e => setPassword(e.target.value)}
                        //         placeholder="password"
                        //     />
                        //     <label htmlFor="floatingPassword">Senha</label>
                        //     <Form.Control.Feedback/>
                        //     <Form.Control.Feedback type="invalid">
                        //         Campo não pode ficar em branco.
                        //     </Form.Control.Feedback>
                        // </div>
                        // <Button type="button" onClick={handleLogin} className="btn btn-lg btn-dark mt-3 mb-3">ENTRAR</Button>
        //             </Form>
        //         </div>
        //     </div>
        // </div>
    )
}

export default Login;