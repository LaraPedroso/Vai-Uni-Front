import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        
        <p>
         Vai pra Uni
        </p>
     
      </header>
    </div>
  );
}

export default App;
